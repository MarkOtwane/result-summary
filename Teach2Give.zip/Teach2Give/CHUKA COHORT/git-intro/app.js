const name;
name = "Mark";