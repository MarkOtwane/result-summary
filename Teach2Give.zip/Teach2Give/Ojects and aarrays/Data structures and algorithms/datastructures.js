// Data structures is a way of organizing data and store them in a computrer for easy access and modification
// Steps of solving a problem or doing something - algorithm(clear, repeatable,)
// Building block of good programming, coding interviews,make code faster, cleaner and scalability
//space complexity(memory used in relation to input size) and time complexity(how and algorithm grows with input size )
//scalability- changed in size and 
// ARRAYS->fixed size collection of elements of the same type, stored in contiguous memory(A group of elements or things of the same type and stored in contiguous memory(row of apartments where each apartment has its fixed position)
//index-based access
////fixed size and Efficient traversal(loop through quickly)

let fruits = []